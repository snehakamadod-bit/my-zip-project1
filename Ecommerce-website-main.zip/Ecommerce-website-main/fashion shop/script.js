 // Array to store cart items
let cart = [];

// Function to add items to the cart
function addToCart(price) {
    const itemName = event.target.parentElement.querySelector('h3').innerText;
    const item = {
        name: itemName,
        price: price
    };

    // Add item to the cart array
    cart.push(item);

    // Update the cart display
    updateCart();
}

// Function to update the cart display
function updateCart() {
    const cartItemsContainer = document.getElementById('cart-items');
    const cartTotal = document.getElementById('cart-total');
    
    // Clear the existing cart items
    cartItemsContainer.innerHTML = '';

    // Calculate the total price
    let total = 0;

    // Loop through the cart and display each item
    cart.forEach((item, index) => {
        const listItem = document.createElement('li');
        listItem.textContent = `${item.name} - ₹${item.price}`;

        // Create a remove button for each item
        const removeButton = document.createElement('button');
        removeButton.textContent = "Remove";
        removeButton.onclick = () => removeFromCart(index);

        // Append the remove button to the list item
        listItem.appendChild(removeButton);

        // Append the list item to the cart
        cartItemsContainer.appendChild(listItem);

        // Add to the total
        total += item.price;
    });

    // Update the total cost
    cartTotal.textContent = total;
}

// Function to remove an item from the cart
function removeFromCart(index) {
    // Remove the item from the cart array
    cart.splice(index, 1);

    // Update the cart display
    updateCart();
}

// Checkout functionality
function checkout() {
    if (cart.length > 0) {
        alert('Proceeding to checkout!');
        // Here, you can add more functionality, like form submission or API calls
    } else {
        alert('Your cart is empty!');
    }
}
